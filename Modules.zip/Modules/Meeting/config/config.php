<?php

return [
    'name' => 'Meeting',
];
