<?php

return [
    'name' => 'Meal',
];
