<?php

return [
    'name' => 'Reception',
];
