<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Admin\\Providers\\AdminServiceProvider',
    1 => 'Modules\\Approval\\Providers\\ApprovalServiceProvider',
    2 => 'Modules\\Canteen\\Providers\\CanteenServiceProvider',
    3 => 'Modules\\HRM\\Providers\\HRMServiceProvider',
    4 => 'Modules\\Meeting\\Providers\\MeetingServiceProvider',
    5 => 'Modules\\Reception\\Providers\\ReceptionServiceProvider',
    6 => 'Modules\\Support\\Providers\\SupportServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Admin\\Providers\\AdminServiceProvider',
    1 => 'Modules\\Approval\\Providers\\ApprovalServiceProvider',
    2 => 'Modules\\Canteen\\Providers\\CanteenServiceProvider',
    3 => 'Modules\\HRM\\Providers\\HRMServiceProvider',
    4 => 'Modules\\Meeting\\Providers\\MeetingServiceProvider',
    5 => 'Modules\\Reception\\Providers\\ReceptionServiceProvider',
    6 => 'Modules\\Support\\Providers\\SupportServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);